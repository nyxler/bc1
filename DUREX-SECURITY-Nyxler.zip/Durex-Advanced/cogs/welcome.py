import discord
from discord.ext import commands
import config

class Welcome(commands.Cog):
    def __init__(self, bot): self.bot=bot
    @commands.Cog.listener()
    async def on_member_join(self, member):
        cid=int(getattr(config,"WELCOME_CHANNEL_ID",0) or 0); channel=member.guild.get_channel(cid) if cid else None
        if channel:
            e=discord.Embed(title="Welcome", description=f"Welcome {member.mention} to **{member.guild.name}**.", color=discord.Color.blurple())
            e.set_thumbnail(url=member.display_avatar.url); e.set_footer(text=f"Member #{member.guild.member_count}")
            try: await channel.send(embed=e)
            except (discord.Forbidden,discord.HTTPException): pass

async def setup(bot): await bot.add_cog(Welcome(bot))
