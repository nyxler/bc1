import discord
from discord.ext import commands

class Roles(commands.Cog):
    def __init__(self, bot): self.bot=bot
    @commands.group(name="role", invoke_without_command=True)
    async def role(self, ctx): await ctx.reply("Use `?role add @member @role`, `?role remove @member @role`, or `?roleinfo @role`.", mention_author=False)
    @role.command(name="add")
    @commands.guild_only()
    @commands.has_permissions(manage_roles=True)
    @commands.bot_has_permissions(manage_roles=True)
    async def role_add(self, ctx, member: discord.Member, role: discord.Role):
        if role.is_default() or role.managed or role >= ctx.guild.me.top_role: return await ctx.reply("I cannot manage that role because of Discord role hierarchy.", mention_author=False)
        await member.add_roles(role, reason=f"Role added by {ctx.author}"); await ctx.reply(f"Added {role.mention} to {member.mention}.", mention_author=False)
    @role.command(name="remove")
    @commands.guild_only()
    @commands.has_permissions(manage_roles=True)
    @commands.bot_has_permissions(manage_roles=True)
    async def role_remove(self, ctx, member: discord.Member, role: discord.Role):
        if role.is_default() or role.managed or role >= ctx.guild.me.top_role: return await ctx.reply("I cannot manage that role because of Discord role hierarchy.", mention_author=False)
        await member.remove_roles(role, reason=f"Role removed by {ctx.author}"); await ctx.reply(f"Removed {role.mention} from {member.mention}.", mention_author=False)
    @commands.command(name="roleinfo")
    @commands.guild_only()
    async def roleinfo(self, ctx, role: discord.Role):
        e=discord.Embed(title=f"Role: {role.name}", color=role.colour); e.add_field(name="ID",value=role.id); e.add_field(name="Members",value=len(role.members)); e.add_field(name="Position",value=role.position); e.add_field(name="Permissions",value=str(role.permissions.value),inline=False)
        await ctx.reply(embed=e,mention_author=False)

async def setup(bot): await bot.add_cog(Roles(bot))
