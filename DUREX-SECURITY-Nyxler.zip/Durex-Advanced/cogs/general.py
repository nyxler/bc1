import discord
from discord.ext import commands

THEME = discord.Color.from_rgb(76, 110, 245)

class HelpSelect(discord.ui.Select):
    def __init__(self, ctx):
        self.ctx = ctx
        options = [
            discord.SelectOption(label="Security", value="Security", description="AntiNuke and Anti-Betrayal"),
            discord.SelectOption(label="Moderation", value="Moderation", description="Kick, ban, timeout, purge and lockdown"),
            discord.SelectOption(label="Utility", value="Utility", description="Ping, server info, user info and polls"),
            discord.SelectOption(label="Roles", value="Roles", description="Role management commands"),
            discord.SelectOption(label="Community", value="Community", description="Giveaways and fun commands"),
        ]
        super().__init__(placeholder="Choose a command category...", min_values=1, max_values=1, options=options)

    async def callback(self, interaction: discord.Interaction):
        if interaction.user.id != self.ctx.author.id:
            return await interaction.response.send_message("This help menu belongs to the command user.", ephemeral=True)
        category = self.values[0]
        cog_map = {"Security": {"Security"}, "Moderation": {"Moderation"}, "Utility": {"General"}, "Roles": {"Roles"}, "Community": {"Fun", "Giveaways"}}
        commands_list = []
        for cmd in self.ctx.bot.commands:
            if cmd.hidden:
                continue
            cog_name = cmd.cog_name or "General"
            if cog_name in cog_map[category]:
                commands_list.append(f"`{self.ctx.clean_prefix}{cmd.qualified_name}` — {cmd.short_doc or 'No description provided.'}")
        embed = discord.Embed(title=f"Durex Security | {category}", description="\n".join(commands_list) or "No commands in this category yet.", color=THEME, timestamp=discord.utils.utcnow())
        embed.set_footer(text=f"Requested by {self.ctx.author}", icon_url=self.ctx.author.display_avatar.url)
        await interaction.response.edit_message(embed=embed, view=self.view)

class HelpView(discord.ui.View):
    def __init__(self, ctx):
        super().__init__(timeout=90)
        self.add_item(HelpSelect(ctx))

class General(commands.Cog):
    def __init__(self, bot): self.bot = bot

    @commands.command()
    async def ping(self, ctx):
        e = discord.Embed(title="Durex Security | Latency", color=THEME, timestamp=discord.utils.utcnow())
        e.add_field(name="Gateway latency", value=f"`{round(self.bot.latency * 1000)} ms`", inline=False)
        e.set_footer(text="Durex Security")
        await ctx.reply(embed=e, mention_author=False)

    @commands.command(name="helpme", aliases=["commands", "helpdesk"])
    async def helpme(self, ctx):
        e = discord.Embed(title="Durex Security | Help Center", description="Select a category from the menu below to browse commands.", color=THEME, timestamp=discord.utils.utcnow())
        e.add_field(name="Prefix", value=f"`{ctx.clean_prefix}`", inline=True)
        e.add_field(name="Security", value="AntiNuke, Anti-Betrayal, whitelist and protected-role monitoring", inline=False)
        if self.bot.user:
            e.set_thumbnail(url=self.bot.user.display_avatar.url)
        e.set_footer(text="Menu expires after 90 seconds")
        await ctx.reply(embed=e, view=HelpView(ctx), mention_author=False)

    @commands.command()
    @commands.guild_only()
    async def serverinfo(self, ctx):
        g = ctx.guild
        e = discord.Embed(title=f"{g.name} | Server Information", color=THEME, timestamp=discord.utils.utcnow())
        e.add_field(name="Members", value=str(g.member_count or "Unknown"), inline=True)
        e.add_field(name="Roles", value=str(len(g.roles)), inline=True)
        e.add_field(name="Channels", value=str(len(g.channels)), inline=True)
        e.add_field(name="Owner", value=f"<@{g.owner_id}>" if g.owner_id else "Unknown", inline=True)
        e.add_field(name="Created", value=discord.utils.format_dt(g.created_at, style="D"), inline=True)
        if g.icon: e.set_thumbnail(url=g.icon.url)
        e.set_footer(text=f"Guild ID: {g.id}")
        await ctx.reply(embed=e, mention_author=False)

    @commands.command()
    @commands.guild_only()
    async def userinfo(self, ctx, member: discord.Member = None):
        m = member or ctx.author
        e = discord.Embed(title=f"User Information | {m}", color=THEME, timestamp=discord.utils.utcnow())
        e.set_thumbnail(url=m.display_avatar.url)
        e.add_field(name="User ID", value=f"`{m.id}`", inline=False)
        e.add_field(name="Account created", value=discord.utils.format_dt(m.created_at, style="F"), inline=False)
        e.add_field(name="Joined server", value=discord.utils.format_dt(m.joined_at, style="F") if m.joined_at else "Unknown", inline=False)
        e.add_field(name="Top role", value=m.top_role.mention, inline=True)
        e.add_field(name="Bot account", value="Yes" if m.bot else "No", inline=True)
        roles = [r.mention for r in reversed(m.roles) if not r.is_default()]
        e.add_field(name=f"Roles ({len(roles)})", value=(" ".join(roles)[:1000] or "No roles"), inline=False)
        perms = [name.replace("_", " ").title() for name, value in m.guild_permissions if value]
        e.add_field(name="Server permissions", value=", ".join(perms)[:1000] or "No special permissions", inline=False)
        e.set_footer(text=f"Requested by {ctx.author}")
        await ctx.reply(embed=e, mention_author=False)

    @commands.command()
    async def avatar(self, ctx, member: discord.Member = None):
        m = member or ctx.author
        e = discord.Embed(title=f"Avatar | {m}", color=THEME, timestamp=discord.utils.utcnow())
        e.set_image(url=m.display_avatar.url)
        await ctx.reply(embed=e, mention_author=False)

    @commands.command()
    @commands.guild_only()
    async def poll(self, ctx, *, question):
        parts = [p.strip() for p in question.split("|")]
        if len(parts) < 2:
            e = discord.Embed(title="Poll | Usage", description=f"`{ctx.clean_prefix}poll Question | Option A | Option B`", color=discord.Color.orange())
            return await ctx.reply(embed=e, mention_author=False)
        e = discord.Embed(title="Community Poll", description=parts[0], color=THEME, timestamp=discord.utils.utcnow())
        marks = ["🇦", "🇧", "🇨", "🇩", "🇪", "🇫", "🇬", "🇭", "🇮", "🇯"]
        for i, opt in enumerate(parts[1:11]): e.add_field(name=f"Option {marks[i]}", value=opt, inline=False)
        e.set_footer(text=f"Poll created by {ctx.author}")
        msg = await ctx.send(embed=e)
        for mark in marks[:min(10, len(parts) - 1)]:
            try: await msg.add_reaction(mark)
            except discord.HTTPException: break

async def setup(bot): await bot.add_cog(General(bot))
