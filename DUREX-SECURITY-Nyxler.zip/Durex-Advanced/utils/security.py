import discord

async def find_audit_actor(guild: discord.Guild, action: discord.AuditLogAction, target_id: int, max_age: float = 15):
    """Only return an actor when a recent audit entry matches the target."""
    try:
        async for entry in guild.audit_logs(limit=12, action=action):
            if getattr(entry.target, "id", None) != target_id:
                continue
            age = (discord.utils.utcnow() - entry.created_at).total_seconds()
            if 0 <= age <= max_age:
                return entry
    except (discord.Forbidden, discord.HTTPException):
        return None
    return None

async def strip_manageable_roles(member: discord.Member, reason: str):
    """Remove roles the bot can manage; never claim this can bypass hierarchy."""
    guild, me = member.guild, member.guild.me
    if me is None or member.id == guild.owner_id or member.bot and member.id == me.id:
        return False, "protected member"
    if me.top_role <= member.top_role:
        return False, "actor's top role is equal to or above the bot's role"
    keep = [r for r in member.roles if r.is_default() or r.managed or r >= me.top_role]
    remove = [r for r in member.roles if r not in keep]
    if not remove:
        return False, "no manageable roles to remove"
    try:
        await member.edit(roles=keep, reason=reason[:480])
        return True, f"removed {len(remove)} manageable role(s)"
    except (discord.Forbidden, discord.HTTPException) as exc:
        return False, f"role stripping failed: {type(exc).__name__}"
