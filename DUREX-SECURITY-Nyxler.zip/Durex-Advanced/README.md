# DUREX SECURITY

**Developed by Nyxler </>**

A modular Python Discord bot with a blue-themed embed style, moderation, security toggles, automod, roles, welcome messages, utilities, games, giveaways, and logging. Prefix: `?`.

## Quick start — Windows
1. Install Python 3.11 or newer.
2. Open this folder and edit `config.py`.
3. Put your bot token in `TOKEN`, your Discord user ID in `OWNER_IDS`, and configure channel IDs if needed.
4. Run `run_windows.bat` or use `py main.py` in a terminal.

## Quick start — Linux / VPS / Cloud Shell
1. Install Python 3.11 or newer.
2. Edit `config.py` with your bot token and IDs.
3. Run `python3 -m pip install -r requirements.txt`.
4. Run `python3 main.py` (or `./run_linux.sh`).

## Discord Developer Portal
Enable **Server Members Intent** and **Message Content Intent**. Invite the bot with the permissions it needs and place its top role above roles it must manage. Avoid granting Administrator unless necessary.

## Commands
- `?autosetup` / `?autosetup status`
- `?antinuke enable all`, `?antinuke disable all`, `?antinuke status`
- `?antinuke enable roles|channels|webhooks|antibot|kicks|bans|guildUpdate`
- `?antinuke whitelist add @member` / `?antinuke whitelist remove @member`
- `?antibetrayal enable|disable|status`
- `?helpme`, `?ping`, `?userinfo`, `?serverinfo`, `?avatar`, `?poll`
- Moderation commands include kick, ban, unban, timeout, purge, slowmode, lock and unlock.
- Other modules include automod, role management, welcome, fun, giveaways and event logging.

## Important feature limits
This is a modular starter, not a claim of full feature parity with another bot. Music/Lavalink, a web dashboard, backup/restore, ticketing, advanced automod rules and persistent database-backed settings are not included in this build. Security toggles only enforce behavior implemented in the corresponding listeners; test in a private server before using in a production community. Discord audit logs can be delayed, and Discord role hierarchy limits what the bot can manage.

## Secret handling
Never publish `config.py` or your bot token. If a token or OAuth secret has been pasted into a chat or public repository, reset it in the Discord Developer Portal before running the bot. `config.py` is excluded by `.gitignore`.
